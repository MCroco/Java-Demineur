D�mineur complet----------------
Url     : http://codes-sources.commentcamarche.net/source/15673-demineur-completAuteur  : cs_DobelDate    : 01/08/2013
Licence :
=========

Ce document intitul� � D�mineur complet � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un petit plagiat du d&eacute;mineur Windows avec les modes de difficult&eacute;s
 et tout ce qu'il faut.
<br />Le code est pas toujours tr&egrave;s &eacute;l&ea
cute;gant (voir m&ecirc;me un peu lourd :) mais il s'en sort pas mal pour la vit
esse [code plus &eacute;l&eacute;gant et plus rapide depuis la derni&egrave;re m
ise &agrave; jour ;-p]
<br />le clique double de l'original (clique gauche et d
roit en m&ecirc;me tps) est remplac&eacute; par un simple clique gauche comme ca
 se voit parfois sur Palm (c'est un poil plus pratique donc bon pour les temps :
 )
<br />
<br />Dobeliou
<br /><a name='conclusion'></a><h2> Conclusion : </h
2>
<br />remarque : 
<br />le timer du d&eacute;mineur de windows semble &eci
rc;tre tr&egrave;s impr&eacute;cis
<br />donc il est possible que vos temps soi
ent plus important avec ce d&eacute;mineur (c'est pas tr&egrave;s flatteur quand
 on y joue ;-)
